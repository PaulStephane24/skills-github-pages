<?php
session_start();
include 'functions.php';
include 'questions.php';

// Initialize or reset game
if (!isset($_SESSION['game_started']) || isset($_POST['reset_game'])) {
    resetGame();
}

// Handle form submissions
if (isset($_POST['start_game'])) {
    $_SESSION['game_started'] = true;
    $_SESSION['player_count'] = $_POST['player_count'];
    $_SESSION['game_mode'] = $_POST['game_mode'];
    
    // Set player names
    for ($i = 0; $i < $_POST['player_count']; $i++) {
        $playerName = !empty($_POST["player_name_$i"]) ? $_POST["player_name_$i"] : "Player " . ($i + 1);
        $_SESSION['players'][$i] = $playerName;
    }
}

// Handle truth or dare selection
if (isset($_POST['truth'])) {
    $mode = $_SESSION['game_mode'];
    $questions = $GLOBALS['truthQuestions'][$mode];
    $_SESSION['current_task'] = $questions[array_rand($questions)];
    $_SESSION['task_type'] = 'truth';
}

if (isset($_POST['dare'])) {
    $mode = $_SESSION['game_mode'];
    $dares = $GLOBALS['dares'][$mode];
    $_SESSION['current_task'] = $dares[array_rand($dares)];
    $_SESSION['task_type'] = 'dare';
}

// Handle next player
if (isset($_POST['next_player'])) {
    $_SESSION['current_player'] = ($_SESSION['current_player'] + 1) % $_SESSION['player_count'];
    $_SESSION['current_task'] = '';
    $_SESSION['task_type'] = '';
}

// Handle random player
if (isset($_POST['random_player'])) {
    $_SESSION['current_player'] = rand(0, $_SESSION['player_count'] - 1);
    $_SESSION['current_task'] = '';
    $_SESSION['task_type'] = '';
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Truth or Dare</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 500px;
            margin: 0 auto;
            background: white;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            overflow: hidden;
        }
        .card-header {
            background-color: #f8f9fa;
            padding: 20px;
            text-align: center;
            border-bottom: 1px solid #e9ecef;
        }
        .card-title {
            margin: 0;
            font-size: 24px;
            color: #333;
        }
        .card-description {
            color: #6c757d;
            margin-top: 5px;
        }
        .card-content {
            padding: 20px;
        }
        .card-footer {
            padding: 15px 20px;
            background-color: #f8f9fa;
            display: flex;
            justify-content: space-between;
            border-top: 1px solid #e9ecef;
        }
        .btn {
            padding: 8px 16px;
            border-radius: 4px;
            border: 1px solid #ccc;
            background-color: #fff;
            cursor: pointer;
            font-size: 14px;
            transition: all 0.2s;
        }
        .btn-primary {
            background-color: #007bff;
            border-color: #007bff;
            color: white;
        }
        .btn-primary:hover {
            background-color: #0069d9;
            border-color: #0062cc;
        }
        .btn-outline {
            background-color: transparent;
            border-color: #ccc;
        }
        .btn-outline:hover {
            background-color: #f8f9fa;
        }
        .btn-block {
            display: block;
            width: 100%;
        }
        .btn-lg {
            padding: 20px;
            font-size: 18px;
        }
        .grid {
            display: grid;
            gap: 10px;
        }
        .grid-cols-2 {
            grid-template-columns: 1fr 1fr;
        }
        .grid-cols-3 {
            grid-template-columns: 1fr 1fr 1fr;
        }
        .space-y-4 > * + * {
            margin-top: 16px;
        }
        .space-y-2 > * + * {
            margin-top: 8px;
        }
        .tabs {
            margin-bottom: 20px;
        }
        .tabs-list {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 10px;
            margin-bottom: 16px;
        }
        .tab-trigger {
            padding: 8px;
            text-align: center;
            border: 1px solid #ccc;
            border-radius: 4px;
            cursor: pointer;
        }
        .tab-trigger.active {
            background-color: #007bff;
            color: white;
            border-color: #007bff;
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-size: 14px;
            font-weight: 500;
        }
        .form-control {
            width: 100%;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }
        .avatar {
            width: 64px;
            height: 64px;
            border-radius: 50%;
            background-color: #007bff;
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            margin: 0 auto 16px;
        }
        .text-center {
            text-align: center;
        }
        .mode-badge {
            display: inline-block;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 500;
        }
        .mode-soft {
            background-color: #d4edda;
            color: #155724;
        }
        .mode-medium {
            background-color: #fff3cd;
            color: #856404;
        }
        .mode-hard {
            background-color: #f8d7da;
            color: #721c24;
        }
        .task-card {
            background-color: #f8f9fa;
            padding: 16px;
            border-radius: 8px;
            margin-bottom: 16px;
        }
        .task-type {
            text-transform: uppercase;
            font-size: 12px;
            font-weight: 600;
            margin-bottom: 8px;
            text-align: center;
        }
        .task-content {
            font-size: 18px;
            text-align: center;
        }
        .flex-center {
            display: flex;
            justify-content: center;
        }
        .player-controls {
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
        .player-count {
            margin: 0 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="card-header">
            <h1 class="card-title">Truth or Dare</h1>
            <p class="card-description">A fun game for friends</p>
        </div>
        
        <div class="card-content">
            <?php if (!$_SESSION['game_started']): ?>
                <!-- Game Setup -->
                <form method="post" class="space-y-4">
                    <div class="tabs">
                        <div class="tabs-list">
                            <div class="tab-trigger <?php echo (!isset($_POST['player_tab']) || $_POST['player_tab'] == '2') ? 'active' : ''; ?>" onclick="document.getElementById('player_tab_2').checked = true">
                                2 Players
                            </div>
                            <div class="tab-trigger <?php echo (isset($_POST['player_tab']) && $_POST['player_tab'] == 'multi') ? 'active' : ''; ?>" onclick="document.getElementById('player_tab_multi').checked = true">
                                3+ Players
                            </div>
                        </div>
                        <input type="radio" id="player_tab_2" name="player_tab" value="2" style="display:none" <?php echo (!isset($_POST['player_tab']) || $_POST['player_tab'] == '2') ? 'checked' : ''; ?>>
                        <input type="radio" id="player_tab_multi" name="player_tab" value="multi" style="display:none" <?php echo (isset($_POST['player_tab']) && $_POST['player_tab'] == 'multi') ? 'checked' : ''; ?>>
                    </div>
                    
                    <div class="space-y-4">
                        <h3 class="text-sm font-medium">Select Game Mode:</h3>
                        <div class="grid grid-cols-3">
                            <button type="button" class="btn <?php echo (!isset($_POST['game_mode']) || $_POST['game_mode'] == 'soft') ? 'btn-primary' : 'btn-outline'; ?>" onclick="document.getElementById('mode_soft').checked = true">Soft</button>
                            <button type="button" class="btn <?php echo (isset($_POST['game_mode']) && $_POST['game_mode'] == 'medium') ? 'btn-primary' : 'btn-outline'; ?>" onclick="document.getElementById('mode_medium').checked = true">Medium</button>
                            <button type="button" class="btn <?php echo (isset($_POST['game_mode']) && $_POST['game_mode'] == 'hard') ? 'btn-primary' : 'btn-outline'; ?>" onclick="document.getElementById('mode_hard').checked = true">Hard</button>
                        </div>
                        <input type="radio" id="mode_soft" name="game_mode" value="soft" style="display:none" <?php echo (!isset($_POST['game_mode']) || $_POST['game_mode'] == 'soft') ? 'checked' : ''; ?>>
                        <input type="radio" id="mode_medium" name="game_mode" value="medium" style="display:none" <?php echo (isset($_POST['game_mode']) && $_POST['game_mode'] == 'medium') ? 'checked' : ''; ?>>
                        <input type="radio" id="mode_hard" name="game_mode" value="hard" style="display:none" <?php echo (isset($_POST['game_mode']) && $_POST['game_mode'] == 'hard') ? 'checked' : ''; ?>>
                    </div>
                    
                    <?php if (!isset($_POST['player_tab']) || $_POST['player_tab'] == '2'): ?>
                        <input type="hidden" name="player_count" value="2">
                        <div class="space-y-2">
                            <div class="form-group">
                                <label for="player_name_0">Player 1 Name</label>
                                <input type="text" id="player_name_0" name="player_name_0" class="form-control" placeholder="Player 1">
                            </div>
                            <div class="form-group">
                                <label for="player_name_1">Player 2 Name</label>
                                <input type="text" id="player_name_1" name="player_name_1" class="form-control" placeholder="Player 2">
                            </div>
                        </div>
                    <?php else: ?>
                        <?php 
                        $playerCount = isset($_POST['player_count']) ? intval($_POST['player_count']) : 3;
                        $playerCount = max(3, min(8, $playerCount));
                        ?>
                        <input type="hidden" name="player_count" value="<?php echo $playerCount; ?>">
                        
                        <div class="grid grid-cols-2 gap-10">
                            <?php for ($i = 0; $i < $playerCount; $i++): ?>
                                <div class="form-group">
                                    <label for="player_name_<?php echo $i; ?>">Player <?php echo $i + 1; ?></label>
                                    <input type="text" id="player_name_<?php echo $i; ?>" name="player_name_<?php echo $i; ?>" class="form-control" placeholder="Player <?php echo $i + 1; ?>">
                                </div>
                            <?php endfor; ?>
                        </div>
                        
                        <div class="player-controls">
                            <button type="submit" name="decrease_players" class="btn btn-outline" <?php echo $playerCount <= 3 ? 'disabled' : ''; ?>>- Player</button>
                            <span class="player-count"><?php echo $playerCount; ?> Players</span>
                            <button type="submit" name="increase_players" class="btn btn-outline" <?php echo $playerCount >= 8 ? 'disabled' : ''; ?>>+ Player</button>
                        </div>
                    <?php endif; ?>
                    
                    <button type="submit" name="start_game" class="btn btn-primary btn-block">Start Game</button>
                </form>
            <?php else: ?>
                <!-- Game Play -->
                <div class="space-y-4">
                    <div class="flex-center">
                        <div class="avatar">
                            <?php echo strtoupper(substr($_SESSION['players'][$_SESSION['current_player']], 0, 1)); ?>
                        </div>
                    </div>
                    
                    <h3 class="text-center"><?php echo $_SESSION['players'][$_SESSION['current_player']]; ?>'s Turn</h3>
                    
                    <div class="text-center">
                        <span class="mode-badge mode-<?php echo $_SESSION['game_mode']; ?>">
                            <?php echo ucfirst($_SESSION['game_mode']); ?> Mode
                        </span>
                    </div>
                    
                    <?php if (empty($_SESSION['current_task'])): ?>
                        <form method="post" class="grid grid-cols-2 gap-10">
                            <button type="submit" name="truth" class="btn btn-outline btn-lg">Truth</button>
                            <button type="submit" name="dare" class="btn btn-outline btn-lg">Dare</button>
                        </form>
                    <?php else: ?>
                        <div class="task-card">
                            <div class="task-type">
                                <?php echo $_SESSION['task_type'] === 'truth' ? 'Truth Question' : 'Dare Challenge'; ?>
                            </div>
                            <div class="task-content">
                                <?php echo $_SESSION['current_task']; ?>
                            </div>
                        </div>
                        
                        <form method="post">
                            <button type="submit" name="next_player" class="btn btn-primary btn-block">Next Player</button>
                        </form>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
        
        <div class="card-footer">
            <?php if ($_SESSION['game_started']): ?>
                <form method="post">
                    <button type="submit" name="reset_game" class="btn btn-outline">Back to Setup</button>
                </form>
                
                <?php if (empty($_SESSION['current_task'])): ?>
                    <form method="post">
                        <button type="submit" name="random_player" class="btn btn-outline">Random Player</button>
                    </form>
                <?php else: ?>
                    <div></div> <!-- Empty div to maintain flex layout -->
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>

