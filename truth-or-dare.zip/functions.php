<?php
// Reset game state
function resetGame() {
    $_SESSION['game_started'] = false;
    $_SESSION['player_count'] = 2;
    $_SESSION['current_player'] = 0;
    $_SESSION['current_task'] = '';
    $_SESSION['task_type'] = '';
    $_SESSION['game_mode'] = 'soft';
    $_SESSION['players'] = [];
    
    // Handle player count changes
    if (isset($_POST['increase_players'])) {
        $_SESSION['player_count'] = min(8, $_POST['player_count'] + 1);
    } elseif (isset($_POST['decrease_players'])) {
        $_SESSION['player_count'] = max(3, $_POST['player_count'] - 1);
    }
}
?>

