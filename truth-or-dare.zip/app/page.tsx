"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Shuffle, Users, User } from "lucide-react"

export default function TruthOrDare() {
  const [gameStarted, setGameStarted] = useState(false)
  const [playerCount, setPlayerCount] = useState(2)
  const [currentPlayer, setCurrentPlayer] = useState(0)
  const [currentTask, setCurrentTask] = useState("")
  const [taskType, setTaskType] = useState("")
  const [gameMode, setGameMode] = useState("soft")
  const [players, setPlayers] = useState(
    Array(8)
      .fill("")
      .map((_, i) => `Player ${i + 1}`),
  )

  const truthQuestions = {
    soft: [
      "What's your favorite movie of all time?",
      "If you could have dinner with any celebrity, who would it be?",
      "What's the most embarrassing song you secretly like?",
      "What's your most unusual talent?",
      "If you could travel anywhere tomorrow, where would you go?",
      "What's the strangest dream you've ever had?",
      "What's your most irrational fear?",
      "What's the most childish thing you still do?",
      "If you could only eat one food for the rest of your life, what would it be?",
      "What's your favorite childhood memory?",
    ],
    medium: [
      "What's the silliest thing you've done in public?",
      "What's the worst fashion trend you've ever participated in?",
      "What's something you've never told anyone in this room?",
      "What was your most awkward moment?",
      "What's the weirdest thing you've eaten?",
      "If you could have any superpower, what would it be and why?",
      "What's your most unpopular opinion?",
      "What's the most adventurous thing you've ever done?",
      "What's the most embarrassing thing in your search history?",
      "If you had to be stuck in an elevator with someone here, who would it be?",
    ],
    hard: [
      "What's the biggest lie you've ever told?",
      "What's your biggest regret?",
      "What's the most rebellious thing you've ever done?",
      "What's one thing you'd change about yourself?",
      "What's the most trouble you've ever been in?",
      "What's a secret you've kept from your parents?",
      "What's the most difficult decision you've had to make?",
      "What's something you're afraid to tell people?",
      "What's the biggest mistake you've made?",
      "If you had to choose someone in this room to be stranded on a desert island with, who would it be and why?",
    ],
  }

  const dares = {
    soft: [
      "Do your best impression of another player",
      "Speak in an accent for the next round",
      "Do 5 jumping jacks",
      "Show everyone your best silly face",
      "Sing the chorus of your favorite song",
      "Do your best dance move",
      "Tell a joke that will make everyone laugh",
      "Imitate your favorite celebrity",
      "Make a funny face and hold it until your next turn",
      "Balance a book on your head while walking across the room",
    ],
    medium: [
      "Let another player post a status on your social media",
      "Call a friend and sing them Happy Birthday, even if it's not their birthday",
      "Show the most recent photo on your phone",
      "Speak in rhymes for the next two rounds",
      "Make up a short song about the player to your right",
      "Try to juggle with three items of the group's choosing",
      "Pretend to be a news reporter and give a breaking news report about something random",
      "Do your best impression of a famous movie scene",
      "Let the group look through your phone for 30 seconds",
      "Text the 5th person in your contacts something silly",
    ],
    hard: [
      "Switch clothes with the person to your right until your next turn",
      "Let someone draw on your face with a washable marker",
      "Call your crush/partner and tell them you miss them on speakerphone",
      "Do 20 push-ups",
      "Eat a spoonful of hot sauce or something spicy",
      "Let the group create a hairstyle for you",
      "Post an embarrassing selfie on your social media",
      "Let the group send a text message to anyone in your contacts",
      "Wear your clothes backwards for the next three rounds",
      "Do your best impression of everyone in the room",
    ],
  }

  const handleTruth = () => {
    const modeQuestions = truthQuestions[gameMode]
    const randomQuestion = modeQuestions[Math.floor(Math.random() * modeQuestions.length)]
    setCurrentTask(randomQuestion)
    setTaskType("truth")
  }

  const handleDare = () => {
    const modeDares = dares[gameMode]
    const randomDare = modeDares[Math.floor(Math.random() * modeDares.length)]
    setCurrentTask(randomDare)
    setTaskType("dare")
  }

  const nextPlayer = () => {
    setCurrentPlayer((prev) => (prev + 1) % playerCount)
    setCurrentTask("")
    setTaskType("")
  }

  const startGame = (count) => {
    setPlayerCount(count)
    setGameStarted(true)
    setCurrentPlayer(0)
    setCurrentTask("")
    setTaskType("")
  }

  const updatePlayerName = (index, name) => {
    const newPlayers = [...players]
    newPlayers[index] = name || `Player ${index + 1}`
    setPlayers(newPlayers)
  }

  return (
    <div className="container mx-auto py-8 px-4">
      <Card className="max-w-md mx-auto">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl">Truth or Dare</CardTitle>
          <CardDescription>A fun game for friends</CardDescription>
        </CardHeader>
        <CardContent>
          {!gameStarted ? (
            <div className="space-y-6">
              <Tabs defaultValue="2" className="w-full">
                <TabsList className="grid grid-cols-2 mb-4">
                  <TabsTrigger value="2" onClick={() => setPlayerCount(2)}>
                    <User className="mr-2 h-4 w-4" />2 Players
                  </TabsTrigger>
                  <TabsTrigger value="multi" onClick={() => setPlayerCount(3)}>
                    <Users className="mr-2 h-4 w-4" />
                    3+ Players
                  </TabsTrigger>
                </TabsList>
                <div className="mb-6 mt-4">
                  <h3 className="text-sm font-medium mb-2">Select Game Mode:</h3>
                  <div className="grid grid-cols-3 gap-2">
                    <Button
                      variant={gameMode === "soft" ? "default" : "outline"}
                      onClick={() => setGameMode("soft")}
                      className="w-full"
                    >
                      Soft
                    </Button>
                    <Button
                      variant={gameMode === "medium" ? "default" : "outline"}
                      onClick={() => setGameMode("medium")}
                      className="w-full"
                    >
                      Medium
                    </Button>
                    <Button
                      variant={gameMode === "hard" ? "default" : "outline"}
                      onClick={() => setGameMode("hard")}
                      className="w-full"
                    >
                      Hard
                    </Button>
                  </div>
                </div>
                <TabsContent value="2" className="space-y-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Player 1 Name</label>
                    <input
                      type="text"
                      className="w-full p-2 border rounded"
                      placeholder="Player 1"
                      onChange={(e) => updatePlayerName(0, e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Player 2 Name</label>
                    <input
                      type="text"
                      className="w-full p-2 border rounded"
                      placeholder="Player 2"
                      onChange={(e) => updatePlayerName(1, e.target.value)}
                    />
                  </div>
                  <Button className="w-full" onClick={() => startGame(2)}>
                    Start Game
                  </Button>
                </TabsContent>
                <TabsContent value="multi" className="space-y-4">
                  <div className="grid grid-cols-2 gap-2">
                    {[...Array(playerCount)].map((_, i) => (
                      <div key={i} className="space-y-1">
                        <label className="text-sm font-medium">Player {i + 1}</label>
                        <input
                          type="text"
                          className="w-full p-2 border rounded"
                          placeholder={`Player ${i + 1}`}
                          onChange={(e) => updatePlayerName(i, e.target.value)}
                        />
                      </div>
                    ))}
                  </div>
                  <div className="flex items-center justify-between">
                    <Button
                      variant="outline"
                      onClick={() => setPlayerCount((prev) => Math.max(3, prev - 1))}
                      disabled={playerCount <= 3}
                    >
                      - Player
                    </Button>
                    <span>{playerCount} Players</span>
                    <Button
                      variant="outline"
                      onClick={() => setPlayerCount((prev) => Math.min(8, prev + 1))}
                      disabled={playerCount >= 8}
                    >
                      + Player
                    </Button>
                  </div>
                  <Button className="w-full" onClick={() => startGame(playerCount)}>
                    Start Game
                  </Button>
                </TabsContent>
              </Tabs>
            </div>
          ) : (
            <div className="space-y-6">
              <div className="flex justify-center">
                <Avatar className="h-16 w-16">
                  <AvatarFallback className="bg-primary text-primary-foreground text-xl">
                    {players[currentPlayer].charAt(0).toUpperCase()}
                  </AvatarFallback>
                </Avatar>
              </div>
              <h3 className="text-center text-lg font-medium">{players[currentPlayer]}'s Turn</h3>
              <div className="text-center text-sm mb-4">
                <span
                  className={`inline-block px-3 py-1 rounded-full ${
                    gameMode === "soft"
                      ? "bg-green-100 text-green-800"
                      : gameMode === "medium"
                        ? "bg-yellow-100 text-yellow-800"
                        : "bg-red-100 text-red-800"
                  }`}
                >
                  {gameMode.charAt(0).toUpperCase() + gameMode.slice(1)} Mode
                </span>
              </div>

              {!currentTask ? (
                <div className="grid grid-cols-2 gap-4">
                  <Button className="h-20 text-lg" variant="outline" onClick={handleTruth}>
                    Truth
                  </Button>
                  <Button className="h-20 text-lg" variant="outline" onClick={handleDare}>
                    Dare
                  </Button>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="bg-muted p-4 rounded-lg">
                    <h4 className="font-medium mb-2 text-center uppercase text-sm">
                      {taskType === "truth" ? "Truth Question" : "Dare Challenge"}
                    </h4>
                    <p className="text-center text-lg">{currentTask}</p>
                  </div>
                  <Button className="w-full" onClick={nextPlayer}>
                    Next Player
                  </Button>
                </div>
              )}
            </div>
          )}
        </CardContent>
        <CardFooter className="flex justify-between">
          {gameStarted && (
            <Button variant="outline" onClick={() => setGameStarted(false)}>
              Back to Setup
            </Button>
          )}
          {gameStarted && !currentTask && (
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setCurrentPlayer(Math.floor(Math.random() * playerCount))}
            >
              <Shuffle className="h-4 w-4" />
            </Button>
          )}
        </CardFooter>
      </Card>
    </div>
  )
}

