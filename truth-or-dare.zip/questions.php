<?php
// Truth questions for different modes
$truthQuestions = [
    'soft' => [
        "What's your favorite movie of all time?",
        "If you could have dinner with any celebrity, who would it be?",
        "What's the most embarrassing song you secretly like?",
        "What's your most unusual talent?",
        "If you could travel anywhere tomorrow, where would you go?",
        "What's the strangest dream you've ever had?",
        "What's your most irrational fear?",
        "What's the most childish thing you still do?",
        "If you could only eat one food for the rest of your life, what would it be?",
        "What's your favorite childhood memory?",
    ],
    'medium' => [
        "What's the silliest thing you've done in public?",
        "What's the worst fashion trend you've ever participated in?",
        "What's something you've never told anyone in this room?",
        "What was your most awkward moment?",
        "What's the weirdest thing you've eaten?",
        "If you could have any superpower, what would it be and why?",
        "What's your most unpopular opinion?",
        "What's the most adventurous thing you've ever done?",
        "What's the most embarrassing thing in your search history?",
        "If you had to be stuck in an elevator with someone here, who would it be?",
    ],
    'hard' => [
        "What's the biggest lie you've ever told?",
        "What's your biggest regret?",
        "What's the most rebellious thing you've ever done?",
        "What's one thing you'd change about yourself?",
        "What's the most trouble you've ever been in?",
        "What's a secret you've kept from your parents?",
        "What's the most difficult decision you've had to make?",
        "What's something you're afraid to tell people?",
        "What's the biggest mistake you've made?",
        "If you had to choose someone in this room to be stranded on a desert island with, who would it be and why?",
    ]
];

// Dares for different modes
$dares = [
    'soft' => [
        "Do your best impression of another player",
        "Speak in an accent for the next round",
        "Do 5 jumping jacks",
        "Show everyone your best silly face",
        "Sing the chorus of your favorite song",
        "Do your best dance move",
        "Tell a joke that will make everyone laugh",
        "Imitate your favorite celebrity",
        "Make a funny face and hold it until your next turn",
        "Balance a book on your head while walking across the room",
    ],
    'medium' => [
        "Let another player post a status on your social media",
        "Call a friend and sing them Happy Birthday, even if it's not their birthday",
        "Show the most recent photo on your phone",
        "Speak in rhymes for the next two rounds",
        "Make up a short song about the player to your right",
        "Try to juggle with three items of the group's choosing",
        "Pretend to be a news reporter and give a breaking news report about something random",
        "Do your best impression of a famous movie scene",
        "Let the group look through your phone for 30 seconds",
        "Text the 5th person in your contacts something silly",
    ],
    'hard' => [
        "Switch clothes with the person to your right until your next turn",
        "Let someone draw on your face with a washable marker",
        "Call your crush/partner and tell them you miss them on speakerphone",
        "Do 20 push-ups",
        "Eat a spoonful of hot sauce or something spicy",
        "Let the group create a hairstyle for you",
        "Post an embarrassing selfie on your social media",
        "Let the group send a text message to anyone in your contacts",
        "Wear your clothes backwards for the next three rounds",
        "Do your best impression of everyone in the room",
    ]
];
?>

